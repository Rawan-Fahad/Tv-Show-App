package com.example.beltexam2_rawanalanzi.model.data

data class Image(
    val medium: String,
    val original: String
)