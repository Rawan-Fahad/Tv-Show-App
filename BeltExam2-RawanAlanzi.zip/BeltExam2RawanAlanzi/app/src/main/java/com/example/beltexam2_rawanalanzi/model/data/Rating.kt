package com.example.beltexam2_rawanalanzi.model.data

data class Rating(
    val average: Double
)