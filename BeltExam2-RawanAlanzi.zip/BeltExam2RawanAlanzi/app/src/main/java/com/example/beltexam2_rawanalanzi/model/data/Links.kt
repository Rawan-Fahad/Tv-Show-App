package com.example.beltexam2_rawanalanzi.model.data

data class Links(
    val self: Self,
    val show: Show
)