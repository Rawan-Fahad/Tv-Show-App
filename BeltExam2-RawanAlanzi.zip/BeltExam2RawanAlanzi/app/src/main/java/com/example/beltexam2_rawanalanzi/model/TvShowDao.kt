package com.example.beltexam2_rawanalanzi.model

import androidx.room.*

@Dao
interface TvShowDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addTvShow(tvShow: TvShowItem_Room)


    @Query("SELECT * FROM tvShow ORDER BY pk ASC")
    fun getTvShow(): List<TvShowItem_Room>



}