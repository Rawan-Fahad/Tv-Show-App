package com.example.beltexam2_rawanalanzi.model.data

data class WebChannel(
    val country: CountryX,
    val id: Int,
    val name: String,
    val officialSite: String
)