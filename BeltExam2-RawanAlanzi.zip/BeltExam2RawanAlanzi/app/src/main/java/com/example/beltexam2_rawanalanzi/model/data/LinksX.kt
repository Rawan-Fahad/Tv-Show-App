package com.example.beltexam2_rawanalanzi.model.data

data class LinksX(
    val nextepisode: Nextepisode,
    val previousepisode: Previousepisode,
    val self: SelfX
)