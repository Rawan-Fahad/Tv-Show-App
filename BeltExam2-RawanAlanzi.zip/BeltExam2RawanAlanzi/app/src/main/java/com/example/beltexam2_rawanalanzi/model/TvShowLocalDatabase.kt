package com.example.beltexam2_rawanalanzi.model

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.beltexam2_rawanalanzi.view.MainActivity


@Database(entities = [TvShowItem_Room::class], version = 1, exportSchema = false)
abstract class TvShowLocalDatabase: RoomDatabase() {

    abstract fun tvShowDao(): TvShowDao

    companion object{
        @Volatile  // writes to this field are immediately visible to other threads
        private var INSTANCE: TvShowLocalDatabase? = null

        fun getDatabase(context: MainActivity): TvShowLocalDatabase {
            val tempInstance = INSTANCE
            if(tempInstance != null){
                return tempInstance
            }
            synchronized(this){  // protection from concurrent execution on multiple threads
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TvShowLocalDatabase::class.java,
                    "tvShow"
                ) //.fallbackToDestructiveMigration()  // Destroys old database on version change
                    .build()
                INSTANCE = instance
                return instance
            }
        }
    }
}