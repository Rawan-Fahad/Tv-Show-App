package com.example.beltexam2_rawanalanzi.model.data

data class DvdCountry(
    val code: String,
    val name: String,
    val timezone: String
)