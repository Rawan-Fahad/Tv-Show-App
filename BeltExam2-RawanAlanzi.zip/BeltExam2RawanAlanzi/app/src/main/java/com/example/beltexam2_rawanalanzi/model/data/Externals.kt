package com.example.beltexam2_rawanalanzi.model.data

data class Externals(
    val imdb: String,
    val thetvdb: Int,
    val tvrage: Int
)