package com.example.beltexam2_rawanalanzi.model.data

data class Self(
    val href: String
)