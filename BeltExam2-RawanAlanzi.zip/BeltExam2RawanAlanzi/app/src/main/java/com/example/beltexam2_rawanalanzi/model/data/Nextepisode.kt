package com.example.beltexam2_rawanalanzi.model.data

data class Nextepisode(
    val href: String
)