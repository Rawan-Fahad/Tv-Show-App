package com.example.beltexam2_rawanalanzi.model.data

class TvShowItem : ArrayList<TvShowItemItem>()