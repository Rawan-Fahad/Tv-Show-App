package com.example.beltexam2_rawanalanzi.model.data

data class Network(
    val country: Country,
    val id: Int,
    val name: String,
    val officialSite: String
)