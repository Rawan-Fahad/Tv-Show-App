package com.example.beltexam2_rawanalanzi.model.data

data class Show(
    val href: String
)