package com.example.beltexam2_rawanalanzi.view

import androidx.recyclerview.widget.DiffUtil

//
class TvShowDiffUtil :DiffUtil.ItemCallback<TvShowItem_API> (){
    override fun areItemsTheSame(oldItem: TvShowItem_API, newItem: TvShowItem_API): Boolean {
        return oldItem==newItem
    }

    override fun areContentsTheSame(oldItem: TvShowItem_API, newItem: TvShowItem_API): Boolean {
        return oldItem==newItem
    }


}
