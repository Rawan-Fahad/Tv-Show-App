package com.example.beltexam2_rawanalanzi.model.data

data class Schedule(
    val days: List<String>,
    val time: String
)